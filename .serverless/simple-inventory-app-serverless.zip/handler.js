(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

var mongoose = __webpack_require__(2);
var Schema = mongoose.Schema;

var itemSchema = new Schema({
  name: { type: String },
  sku: { type: String },
  code: { type: String },
  quantity: { type: Number, default: 0 }
}, { timestamps: true });

itemSchema.index({ name: 1, sku: 1, code: 1, name: 'text' });
const Item = mongoose.model('Item', itemSchema);
module.exports = Item;

/***/ }),
/* 1 */
/***/ (function(module, exports) {

class BaseError extends Error {
    constructor(httpCode = 500, message = 'ServerError') {
        super(message);
        this.httpCode = httpCode;
        this.message = message;
    }
    toJson() {
        return {
            stack: this.stack,
            message: this.message
        };
    }
}

class NotFoundError extends BaseError {
    constructor(message = 'Not found object') {
        super(404, message);
    }
}

class DuplicateObjectError extends BaseError {
    constructor(message = 'Duplicate object') {
        super(409, message);
    }
}

class BusinessValidationError extends BaseError {
    constructor(message = 'Business Validation Error') {
        super(409, message);
    }
}

class FormatValidationError extends BaseError {
    constructor(errors) {
        super(400, 'Format Validation Error');
        this.errors = errors;
    }

    toJson() {
        const error = super.toJson();
        error.errors = this.errors;
        return error;
    }
}

module.exports = {
    BaseError,
    NotFoundError,
    DuplicateObjectError,
    BusinessValidationError,
    FormatValidationError
};

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("mongoose");

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

const _ = __webpack_require__(8);
const Item = __webpack_require__(0);
const { DuplicateObjectError, NotFoundError } = __webpack_require__(1);

class ItemService {
    static async addNewItem(item) {
        try {
            const existingItem = await Item.findOne({ name: item.name }).exec();
            if (!_.isNil(existingItem)) throw new DuplicateObjectError('An item with the same name exist');
            return await Item.create(item);
        } catch (e) {
            throw e;
        }
    }

    static async deleteItem(itemId) {
        try {
            const item = await Item.findByIdAndDelete(itemId).exec();
            this.validateItemExitence({ _id: itemId });
            return item;
        } catch (e) {
            throw e;
        }
    }

    static async updateItem(item) {
        try {
            const existingItem = await Item.findOne({ name: item.name }).exec();
            if (!_.isNil(existingItem) && existingItem._id.toString() !== item._id) {
                throw new DuplicateObjectError('An item with the same name exist');
            }

            const updatedItem = await Item.findByIdAndUpdate(item._id, item).exec();
            this.validateItemExitence(updatedItem);
            return item;
        } catch (e) {
            throw e;
        }
    }
    static async getItemById(_id) {
        try {
            const items = await this.getItems({ _id });
            this.validateItemExitence(items.length > 0 ? items[0] : null);
            return items[0];
        } catch (e) {
            throw e;
        }
    }
    static async getItems(item = {}) {
        try {
            return Item.find(item).sort({ createdAt: -1 }).exec();
        } catch (e) {
            throw e;
        }
    }

    static validateItemExitence(item) {
        try {
            if (_.isNil(item)) throw new NotFoundError('Item does not exist');
        } catch (e) {
            throw e;
        }
    }
}

module.exports = ItemService;

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = {
    ITEM_INVENTORY_OPERATION: 'operation',
    ITEM_INVENTORY_OPERATION_GO_IN: 'goIn',
    ITEM_INVENTORY_OPERATION_COME_OUT: 'comeOut'
};

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

const ajv = __webpack_require__(6);
const Validator = new ajv();
const mongoose = __webpack_require__(2);
const url = 'mongodb+srv://admin:12345678r@cluster0-f79su.mongodb.net/test';
const ItemModel = __webpack_require__(0);
const { ItemInventoryProcess, ItemService } = __webpack_require__(7);
const { BaseError } = __webpack_require__(1);
const {
  CREATE_ITEM_SCHEME,
  OBJECTID_SCHEME,
  QUANTITY_SCHEME,
  ITEM_OPERATION_SCHEME
} = __webpack_require__(10);

const CONSTANTS = __webpack_require__(4);

function genereateError(err) {
  const errorResponse = {};
  if (err instanceof BaseError) {
    errorResponse.statusCode = err.httpCode;
    errorResponse.body = JSON.stringify(err.toJson());
  } else {
    errorResponse.statusCode = 500;
    errorResponse.body = 'Something broke!';
  }
  return errorResponse;
}

const listItems = async (event, context) => {
  try {
    mongoose.connect(url, { useNewUrlParser: true });
    const items = await ItemService.getItems();
    console.log(items);
    return {
      statusCode: 200,
      body: JSON.stringify(items)
    };
  } catch (e) {
    console.log(e);
    return genereateError(e);
  }
};

const getItemById = async (event, context) => {
  try {
    mongoose.connect(url, { useNewUrlParser: true });
    const itemId = event.pathParameters.id;
    const item = await ItemService.getItemById(itemId);
    return {
      statusCode: 200,
      body: JSON.stringify(item)
    };
  } catch (e) {
    return genereateError(e);
  }
};

const deleteItem = async (event, context) => {
  try {
    Validator.validate(OBJECTID_SCHEME, event.pathParameters);
    mongoose.connect(url, { useNewUrlParser: true });
    const itemId = event.pathParameters.id;
    await ItemService.deleteItem(itemId);
    return {
      statusCode: 200
    };
  } catch (e) {
    return genereateError(e);
  }
};

const updateItem = async (event, context) => {
  try {
    Validator.validate(OBJECTID_SCHEME, event.pathParameters);
    Validator.validate(CREATE_ITEM_SCHEME, event.body);
    mongoose.connect(url, { useNewUrlParser: true });
    const data = JSON.parse(event.body);
    const updatedItem = await ItemService.updateItem(data);
    return {
      statusCode: 200,
      body: JSON.stringify(updatedItem)
    };
  } catch (e) {
    return genereateError(e);
  }
};

const createItem = async (event, context) => {
  try {
    Validator.validate(OBJECTID_SCHEME, event.pathParameters);
    Validator.validate(CREATE_ITEM_SCHEME, event.body);
    mongoose.connect(url, { useNewUrlParser: true });
    const data = JSON.parse(event.body);
    const newItem = await ItemService.addNewItem(data);
    return {
      statusCode: 200,
      body: JSON.stringify(newItem)
    };
  } catch (e) {
    return genereateError(e);
  }
};

const itemProcess = async (event, context) => {
  try {
    Validator.validate(OBJECTID_SCHEME, event.pathParameters);
    Validator.validate(QUANTITY_SCHEME, event.body);
    Validator.validate(ITEM_OPERATION_SCHEME, event.queryStringParameters);
    mongoose.connect(url, { useNewUrlParser: true });
    const data = JSON.parse(event.body);
    const itemId = event.pathParameters.id;
    switch (event.queryStringParameters[CONSTANTS.ITEM_INVENTORY_OPERATION]) {
      case CONSTANTS.ITEM_INVENTORY_OPERATION_GO_IN:
        await ItemInventoryProcess.itemGoIn(itemId, data.quantity);
        break;
      case CONSTANTS.ITEM_INVENTORY_OPERATION_COME_OUT:
        await ItemInventoryProcess.itemComeOut(itemId, data.quantity);
        break;
    }
    return {
      statusCode: 200
    };
  } catch (e) {
    return genereateError(e);
  }
};

module.exports = {
  listItems,
  getItemById,
  deleteItem,
  updateItem,
  createItem,
  itemProcess
};

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("ajv");

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = {
    ItemService: __webpack_require__(3),
    ItemInventoryProcess: __webpack_require__(9)
};

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

const Item = __webpack_require__(0);
const ItemService = __webpack_require__(3);
const {
    BusinessValidationError
} = __webpack_require__(1);

class ItemInventoryProcess {
    static async itemGoIn(itemId, goInQuantity) {
        try {
            const item = await Item.findByIdAndUpdate(itemId, { $inc: { quantity: goInQuantity } }, { new: true });
            ItemService.validateItemExitence(item);
            return item;
        } catch (e) {
            throw e;
        }
    }

    static async itemComeOut(itemId, comeOutQuantity) {
        try {
            const existingItem = await Item.findById(itemId).exec();
            ItemService.validateItemExitence(existingItem);
            existingItem.quantity -= comeOutQuantity;
            if (existingItem.quantity < 0) {
                throw new BusinessValidationError('If this quantity comes out, item quantity will be less than zero');
            }
            const item = await Item.findByIdAndUpdate(itemId, { $inc: { quantity: -comeOutQuantity } }, { new: true });

            return item;
        } catch (e) {
            throw e;
        }
    }

}

module.exports = ItemInventoryProcess;

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

const CONSTANTS = __webpack_require__(4);

const CREATE_ITEM_SCHEME = {
    type: 'object',
    properties: {
        _id: { type: 'string', pattern: '^[0-9a-fA-F]{24}$' },
        name: { type: 'string', minLength: 3 },
        sku: { type: 'string', minLength: 3 },
        code: { type: 'string' },
        quantity: { type: 'number', minimum: 0 }
    },
    required: ['name', 'sku']
};

const OBJECTID_SCHEME = {
    type: 'object',
    properties: {
        id: { pattern: '^[0-9a-fA-F]{24}$' }
    }
};

const QUANTITY_SCHEME = {
    type: 'object',
    properties: {
        _id: { type: 'string', pattern: '^[0-9a-fA-F]{24}$' },
        quantity: { type: 'number' }
    },
    required: ['quantity', '_id']
};

const ITEM_OPERATION_SCHEME = {
    type: 'object',
    properties: {
        operation: { type: 'string', enum: [CONSTANTS.ITEM_INVENTORY_OPERATION_COME_OUT, CONSTANTS.ITEM_INVENTORY_OPERATION_GO_IN] }
    },
    required: ['operation'],
    additionalProperties: false
};
module.exports = {
    CREATE_ITEM_SCHEME,
    OBJECTID_SCHEME,
    QUANTITY_SCHEME,
    ITEM_OPERATION_SCHEME
};

/***/ })
/******/ ])));
//# sourceMappingURL=handler.js.map